import {View} from 'react-native';

const Tab4 = () => {
  return <View></View>;
};

export default Tab4;
