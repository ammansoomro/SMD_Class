import {View} from 'react-native';

const Settings = () => {
  return <View></View>;
};

export default Settings;
