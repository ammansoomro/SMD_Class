import {View} from 'react-native';

const Tab3 = () => {
  return <View></View>;
};

export default Tab3;
