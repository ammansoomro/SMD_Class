
// APP.js
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const Stack = createNativeStackNavigator();


const App_ = () => {

    <NavigationContainer>
        <Stack.Navigator>
            <Stack.Screen name="xyz" option={{ title: "HELLO WORLD!" }} />
            <Stack.Screen name="abc" />
        </Stack.Navigator>
    </NavigationContainer>

}

export default App_;





// COUNTRIES.js
import { Text, View, TouchableOpacity, FlatList } from 'react-native';
import { useEffect, useState } from 'react';

const Countries = ({ navigation }) => {
    const [filter, setFiltered] = useState([]);
    const [countries, setCoutries] = useState([]);
    const [search, setSearch] = useState([]);

    useEffect(() => {
        const getData = async () => {
            const response = await fetch('API');
            const data = response.json();
            setCoutries(data);
            setFiltered(data);
        }
    }, [])

    useEffect(() => {
        if (search == "") {
            setFiltered(countries);
        }
        let filteredC = countries.filter((coutry) => coutry.Name.toLowerCase().includes(search.toLowerCase()));
        setFiltered(filteredC);
    }, [])

    const DisplayCountry = ({ item, index }) => {
        return (
            <TouchableOpacity onPress={() => navigation.navigate('cities', { cityID: item.id })} >
                <View>
                    <Text>
                        {item.name}
                    </Text>
                    <Text>
                        {item.CurrencyName}
                    </Text>
                </View>
            </TouchableOpacity>
        )
    }

    return (
        <View>
            <FlatList data={filter} renderItem={DisplayCountry} />
        </View>
    )
}

